<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => '127.0.0.1:3306',
    'dbname' => 'phpshop',
    'user' => 'root',
    'password' => '',
);
