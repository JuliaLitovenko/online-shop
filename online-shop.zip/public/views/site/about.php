<?php include ROOT . '/views/layouts/header.php'; ?>

<section>
    <div class="container">
        <div class="row">

            <div class="col-lg-6">
                <h4>Информация о магазине</h4>

                <br/>

                <p>В нашем интернет-магазине Вы можете подобрать любую обувь на Ваш вкус и цвет. Качество товара гарантируем. Также можно заказать индивидуальный пошив для не стандартных и эксклюзивных моделей. Доставка в любую точку Украины Новой Почтой.</p>


            </div>
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>